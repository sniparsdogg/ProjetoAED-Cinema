package pt.ulusofona.deisi.aedProj2018;

public class Actor2 {
    int id;
    String nome;
    int filmes;
    public Actor2(int id,String nome,int filmes){
        this.id=id;
        this.nome=nome;
        this.filmes=filmes;
    }
}
